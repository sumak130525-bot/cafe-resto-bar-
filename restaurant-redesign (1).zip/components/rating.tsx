"use client"

import { useState } from "react"
import { Star } from "lucide-react"
import Link from "next/link"

export function Rating() {
  const [hovered, setHovered] = useState(0)
  const [selected, setSelected] = useState(0)

  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-2xl px-6 text-center">
        <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
          ¡Califícanos!
        </h2>
        
        <div className="mt-8 flex items-center justify-center gap-2">
          {[1, 2, 3, 4, 5].map((rating) => (
            <button
              key={rating}
              type="button"
              onMouseEnter={() => setHovered(rating)}
              onMouseLeave={() => setHovered(0)}
              onClick={() => setSelected(rating)}
              className="transition-transform duration-200 hover:scale-125 focus:outline-none"
            >
              <Star
                className={`h-10 w-10 transition-colors duration-200 ${
                  rating <= (hovered || selected)
                    ? "fill-secondary text-secondary"
                    : "text-muted-foreground"
                }`}
              />
            </button>
          ))}
        </div>

        <p className="mt-6 text-muted-foreground">
          Ayúdanos a mejorar continuamente con tu opinión
        </p>

        <Link
          href="https://www.google.com/maps/place/SUMAK/@-32.8949517,-68.829301,19z/data=!3m1!4b1!4m16!1m9!3m8!1s0x967e09a1dd6eefdd:0x698ad41b5908215c!2sSUMAK!8m2!3d-32.8949528!4d-68.8286573!9m1!1b1!16s%2Fg%2F11xgssdlt9!3m5!1s0x967e09a1dd6eefdd:0x698ad41b5908215c!8m2!3d-32.8949528!4d-68.8286573!9m1!1b1!16s%2Fg%2F11xgssdlt9!3m7!1s0x967e09a1dd6eefdd:0x698ad41b5908215c!8m2!3d-32.8949528!4d-68.8286573!9m1!1b1!16s%2Fg%2F11xgssdlt9!3m5!1s0x967e09a1dd6eefdd:0x698ad41b5908215c!8m2!3d-32.8949528!4d-68.8286573!9m1!1b1!16s%2Fg%2F11xgssdlt9!3m5!1s0x967e09a1dd6eefdd:0x698ad41b5908215c!8m2!3d-32.8949528!4d-68.8286573!16s%2Fg%2F11xgssdlt9?entry=ttu&g_ep=EgoyMDI1MTEwOS4wIKXMDSoASAFQAw%3D%3D"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-accent px-8 py-3 font-medium text-accent-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/25"
        >
          <Star className="h-5 w-5" />
          Calificar en Google Maps
        </Link>
      </div>
    </section>
  )
}
