export function About() {
  return (
    <section className="border-y border-border/40 bg-card py-16 md:py-24">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <h2 className="font-serif text-3xl font-bold text-primary md:text-4xl lg:text-5xl">
          Gastronomía Boliviana
        </h2>
        <div className="mt-2 flex items-center justify-center gap-4">
          <span className="h-px w-12 bg-secondary" />
          <span className="h-1.5 w-1.5 rounded-full bg-secondary" />
          <span className="h-px w-12 bg-secondary" />
        </div>
        <p className="mt-8 text-lg leading-relaxed text-muted-foreground md:text-xl">
          En SUMAK, celebramos la rica tradición culinaria de Bolivia con auténticos sabores que conectan a las personas con la cultura andina. Nuestros platos están preparados con ingredientes frescos y seleccionados, siguiendo recetas tradicionales transmitidas de generación en generación. Cada bocado es una experiencia única que combina el sabor ancestral con la calidad moderna.
        </p>
      </div>
    </section>
  )
}
