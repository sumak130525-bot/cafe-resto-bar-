import Image from "next/image"

export function Hero() {
  return (
    <section className="relative py-12 md:py-20">
      <div className="mx-auto max-w-5xl px-6">
        <div className="relative overflow-hidden rounded-2xl shadow-2xl shadow-primary/10">
          <Image
            src="https://i.imgur.com/hmMHpew.jpg"
            alt="SUMAK - Hermoso Agradable y Delicioso"
            width={1200}
            height={600}
            className="w-full object-cover"
            priority
            unoptimized
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
        </div>
      </div>
    </section>
  )
}
