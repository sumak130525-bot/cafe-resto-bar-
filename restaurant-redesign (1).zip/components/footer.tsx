import Link from "next/link"
import { Facebook, Wifi } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-background py-8">
      <div className="mx-auto max-w-7xl px-6 text-center">
        <p className="text-sm text-muted-foreground">
          &copy; 2024 SUMAK Restaurante Boliviano. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  )
}

export function FloatingWifiButton() {
  return (
    <Link
      href="https://www.facebook.com/profile.php?id=61576603961881"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-[#1877F2] px-5 py-3 font-medium text-white shadow-lg shadow-[#1877F2]/30 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#1877F2]/40"
    >
      <Wifi className="h-5 w-5" />
      <Facebook className="h-5 w-5" />
    </Link>
  )
}
