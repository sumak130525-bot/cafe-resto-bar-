import { MenuItem } from "./menu-item"

const menuItems = [
  {
    name: "Sopa de Mani",
    price: 4000,
    image: "https://i.imgur.com/wsXLi1U.png",
    description: "Sopa tradicional boliviana hecha con maní, alita de pollo, papas y verduras.",
    whatsappLink: "https://wa.me/p/25005123959173299/5492617526242"
  },
  {
    name: "Sopa de Trigo",
    price: 4000,
    image: "https://i.imgur.com/P2j7zsP.jpg",
    description: "Sopa nutritiva con trigo, carne y verduras frescas.",
    whatsappLink: "https://wa.me/p/24938218685848355/5492617526242"
  },
  {
    name: "Sopa de Pata",
    price: 4000,
    image: "https://i.imgur.com/OTcMOHx.jpg",
    description: "Sopa contundente con pata de res, chuño, papas y maíz.",
    whatsappLink: "https://wa.me/p/24938218685848355/5492617526242"
  },
  {
    name: "Sopa Puchero",
    price: 4500,
    image: "https://i.imgur.com/BTKwPPZ.jpg",
    description: "Sopa tradicional con carne, verduras y arroz.",
    whatsappLink: "https://wa.me/p/24739595605724252/5492617526242"
  },
  {
    name: "Picante de Pollo",
    price: 8000,
    image: "https://i.imgur.com/LoOi1IH.png",
    description: "Pollo en salsa con arroz, papa y chuño.",
    whatsappLink: "https://wa.me/p/25008224428838935/5492617526242"
  },
  {
    name: "Aji de Lengua",
    price: 8000,
    image: "https://i.imgur.com/ImUMczr.png",
    description: "Lengua de res en salsa de ají con papas, arroz, chuño.",
    whatsappLink: "https://wa.me/p/24938218685848355/5492617526242"
  },
  {
    name: "Carne a la Olla",
    price: 8000,
    image: "https://tse4.mm.bing.net/th/id/OIP.c-FSfaI6GyFxvm1y9DNWTAHaFS?pid=Api&P=0&h=180",
    description: "Carne de res cocida con arroz y papas.",
    whatsappLink: "https://wa.me/p/25532099679708539/5492617526242"
  },
  {
    name: "Falso Conejo",
    price: 8000,
    image: "https://i.imgur.com/Ompc66w.jpeg",
    description: "Plato tradicional con carne de res en salsa con arroz, papa, chuño.",
    whatsappLink: "https://wa.me/p/25532099679708539/5492617526242"
  },
  {
    name: "Sil Pancho",
    price: 8000,
    image: "https://i.imgur.com/zjPVtZe.jpg",
    description: "Plato tipico compuesto de carne de res (tipo hamburgesa),con hevo frito, papas y arroz.",
    whatsappLink: "https://wa.me/p/25264074013230866/5492617526242"
  },
  {
    name: "Milanesa",
    price: 10000,
    image: "https://img.freepik.com/fotos-premium/plato-combo-colombiano-chuleta-valluna-milanesa-ternera-papas-fritas-arroz-blanco-cocido-ensalada-tomate-lechuga_449839-19496.jpg",
    description: "Milanesa de carne con papas fritas y ensalada.",
    whatsappLink: "https://wa.me/p/24088516720779776/5492617526242"
  },
  {
    name: "Napolitana",
    price: 12000,
    image: "https://i.imgur.com/y5TKHhp.png",
    description: "Milanesa con salsa de tomate y queso acompañado de arroz,papas fritas y ensalda.",
    whatsappLink: "https://wa.me/p/25008224428838935/5492617526242"
  },
  {
    name: "Costeleta",
    price: 11000,
    image: "https://tse4.mm.bing.net/th/id/OIP.XMkcMHKSqXt-1iBojYzF0wAAAA?pid=Api&P=0&h=180",
    description: "Costeleta de res con papas, arroz y ensalada.",
    whatsappLink: "https://wa.me/p/25620185937599275/5492617526242"
  },
  {
    name: "Chicharrón",
    price: 11000,
    image: "https://i.imgur.com/cX4SPII.jpg",
    description: "Chicharrón crujiente con mote(maiz blanco cocido) y papa hervida.",
    whatsappLink: "https://wa.me/p/25620185937599275/5492617526242"
  },
  {
    name: "Pescado Sábalo Frito",
    price: 18000,
    image: "https://i.imgur.com/Dqc1rK6.jpg",
    description: "Pescado sábalo frito con mote (maiz cocido) y papa hervida.",
    whatsappLink: "https://wa.me/p/25620185937599275/5492617526242"
  },
  {
    name: "Empanadas Fritas o al Horno",
    price: 12000,
    image: "https://i.imgur.com/iSj4WGL.jpg",
    description: "Empanadas rellenas de carne (docena).",
    whatsappLink: "https://wa.me/p/25066116826402222/5492617526242"
  },
  {
    name: "Empanadas Salteñas",
    price: 1500,
    image: "https://i.imgur.com/0BKyeBl.jpg",
    description: "Empanadas salteñas de pollo con huevo, aceituna pasas de uva (unidad).",
    whatsappLink: "https://wa.me/p/32146493081665375/5492617526242"
  },
  {
    name: "Porción de Papas Fritas",
    price: 4000,
    image: "https://tse2.mm.bing.net/th/id/OIP.weVnIzzCXpCsXnofqh7-PQHaEF?pid=Api&P=0&h=180",
    description: "Porción generosa de papas fritas crujientes.",
    whatsappLink: "https://wa.me/p/24983416251351779/5492617526242"
  },
  {
    name: "Porción de Salchipapas",
    price: 6000,
    image: "https://tse2.mm.bing.net/th/id/OIP.JW-GcPcRFP9gjE60CP0Y3QHaEK?pid=Api&P=0&h=180",
    description: "Salchichas con papas fritas y salsa especial.",
    whatsappLink: "https://wa.me/p/24774109948878372/5492617526242"
  },
  {
    name: "Lengua a la Vinagreta",
    price: 5000,
    image: "https://i.imgur.com/HYPIzuB.jpeg",
    description: "Lengua cocida con vinagreta especial acompañado con pan.",
    whatsappLink: "https://wa.me/p/25452272261047611/5492617526242"
  },
  {
    name: "Fricase",
    price: 9000,
    image: "https://i.imgur.com/ZU8p4rG.jpeg",
    description: "Plato tradicional boliviano con cerdo, papas y mote.",
    whatsappLink: "https://wa.me/p/25005123959173299/5492617526242"
  },
  {
    name: "Api mas Sopaipilla",
    price: 3500,
    image: "https://i.imgur.com/SuAeI8p.jpeg",
    description: "Api caliente acompañado de sopaipillas recién hechas.",
    whatsappLink: "https://wa.me/p/25005123959173299/5492617526242"
  },
  {
    name: "Chairo",
    price: 4500,
    image: "https://i.imgur.com/BTKwPPZ.jpg",
    description: "Sopa tradicional paceña con chuño, carne y verduras.",
    whatsappLink: "https://wa.me/p/25005123959173299/5492617526242"
  },
  {
    name: "Majadito",
    price: 8500,
    image: "https://i.imgur.com/LoOi1IH.png",
    description: "Arroz con charque, plátano frito y huevo.",
    whatsappLink: "https://wa.me/p/25008224428838935/5492617526242"
  },
  {
    name: "Sajta de Pollo",
    price: 8000,
    image: "https://i.imgur.com/LoOi1IH.png",
    description: "Pollo en salsa de ají amarillo con chuño y papa.",
    whatsappLink: "https://wa.me/p/25008224428838935/5492617526242"
  },
  {
    name: "Charque",
    price: 9500,
    image: "https://i.imgur.com/Ompc66w.jpeg",
    description: "Carne seca con mote, papa, queso y huevo.",
    whatsappLink: "https://wa.me/p/25532099679708539/5492617526242"
  },
  {
    name: "Ranga Ranga",
    price: 7500,
    image: "https://i.imgur.com/ImUMczr.png",
    description: "Guiso de mondongo con ají y papas.",
    whatsappLink: "https://wa.me/p/24938218685848355/5492617526242"
  },
  {
    name: "Cuñapé",
    price: 2000,
    image: "https://i.imgur.com/0BKyeBl.jpg",
    description: "Pancitos de queso y almidón de yuca (unidad).",
    whatsappLink: "https://wa.me/p/32146493081665375/5492617526242"
  },
  {
    name: "Tucumanas",
    price: 1500,
    image: "https://i.imgur.com/iSj4WGL.jpg",
    description: "Empanadas fritas rellenas de carne (unidad).",
    whatsappLink: "https://wa.me/p/25066116826402222/5492617526242"
  },
  {
    name: "Anticucho",
    price: 6000,
    image: "https://i.imgur.com/cX4SPII.jpg",
    description: "Brochetas de corazón de res con papa y salsa de maní.",
    whatsappLink: "https://wa.me/p/25620185937599275/5492617526242"
  },
  {
    name: "Llajua",
    price: 1000,
    image: "https://i.imgur.com/wsXLi1U.png",
    description: "Salsa picante tradicional de locoto y tomate.",
    whatsappLink: "https://wa.me/p/25005123959173299/5492617526242"
  }
]

export function Menu() {
  return (
    <section className="border-t border-border/40 bg-card py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center">
          <h2 className="font-serif text-3xl font-bold text-primary md:text-4xl lg:text-5xl">
            Nuestro Menú
          </h2>
          <div className="mt-2 flex items-center justify-center gap-4">
            <span className="h-px w-12 bg-secondary" />
            <span className="h-1.5 w-1.5 rounded-full bg-secondary" />
            <span className="h-px w-12 bg-secondary" />
          </div>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {menuItems.map((item) => (
            <MenuItem key={item.name} {...item} />
          ))}
        </div>
      </div>
    </section>
  )
}
