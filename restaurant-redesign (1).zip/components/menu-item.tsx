"use client"

import Image from "next/image"
import Link from "next/link"
import { ShoppingBag } from "lucide-react"

interface MenuItemProps {
  name: string
  price: number
  image: string
  description: string
  whatsappLink: string
}

export function MenuItem({ name, price, image, description, whatsappLink }: MenuItemProps) {
  return (
    <article className="group relative overflow-hidden rounded-xl border border-border/50 bg-card transition-all duration-500 hover:border-secondary/50 hover:shadow-xl hover:shadow-secondary/5">
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
          unoptimized
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-60" />
        <div className="absolute bottom-4 right-4">
          <span className="rounded-full bg-primary px-4 py-1.5 text-lg font-bold text-primary-foreground">
            ${price}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="font-serif text-xl font-semibold text-foreground transition-colors group-hover:text-secondary">
          {name}
        </h3>
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
        
        <Link
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-primary py-3 font-medium text-primary-foreground transition-all duration-300 hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/25"
        >
          <ShoppingBag className="h-5 w-5" />
          Pedir
        </Link>
      </div>
    </article>
  )
}
