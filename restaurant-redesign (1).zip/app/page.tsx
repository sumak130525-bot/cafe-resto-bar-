import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Rating } from "@/components/rating"
import { Menu } from "@/components/menu"
import { Footer, FloatingWifiButton } from "@/components/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <About />
      <Rating />
      <Menu />
      <Footer />
      <FloatingWifiButton />
    </main>
  )
}
